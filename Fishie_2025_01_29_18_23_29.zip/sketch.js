function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(142, 202, 230);
  fill(140, 179, 105)
  triangle(297,150,260,200,270,260)
  fill(0, 41, 107)
  ellipse(200,200,125,80)
  fill(255, 252, 242)
  ellipse(155,200,20)
  fill(11, 9, 10)
  ellipse(149,200,7)
  fill(140, 179, 105)
  triangle(185,185,185,200,200,200)
  fill(0, 78, 100)
  ellipse(139,215,5)
  ellipse(142,220,5)
  fill(142,202,230)
  ellipse(120,180,20)
  ellipse(140,140,20)
  ellipse(110,100,20)
  fill(255, 237, 216)
  rect(0,350,400,100)
}